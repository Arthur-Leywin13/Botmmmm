const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    downloadMediaMessage
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const P = require('pino');
const fs = require('fs');
const path = require('path');
const { handleCommand } = require('../commands');
const { viewOnceStore } = require('./viewonce');

async function startWhatsAppBot({ sessionId, authDir, onQR, onConnected, onDisconnected }) {
    if (!fs.existsSync(authDir)) {
        fs.mkdirSync(authDir, { recursive: true });
    }

    const { state, saveCreds } = await useMultiFileAuthState(authDir);

    const sock = makeWASocket({
        logger: P({ level: 'silent' }),
        auth: state,
        printQRInTerminal: false,
        markOnlineOnConnect: true,
        browser: ['WhatsApp Bot', 'Chrome', '1.0.0'],
        // Nécessaire pour Render (pas de display)
        generateHighQualityLinkPreview: false,
    });

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update;

        if (qr && onQR) {
            await onQR(qr);
        }

        if (connection === 'close') {
            const reason = (lastDisconnect?.error instanceof Boom)
                ? lastDisconnect.error.output?.statusCode
                : null;

            const shouldReconnect = reason !== DisconnectReason.loggedOut;

            console.log(`❌ [${sessionId}] Connexion fermée. Raison: ${reason}. Reconnexion: ${shouldReconnect}`);

            if (onDisconnected) onDisconnected();

            if (shouldReconnect) {
                setTimeout(() => {
                    startWhatsAppBot({ sessionId, authDir, onQR, onConnected, onDisconnected });
                }, 5000);
            }
        } else if (connection === 'open') {
            const phone = '+' + sock.user.id.split(':')[0];
            if (onConnected) onConnected(phone);
        }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;

        for (const msg of messages) {
            if (!msg.message) continue;

            const jid = msg.key.remoteJid;
            const isGroup = jid.endsWith('@g.us');
            const sender = msg.key.participant || msg.key.remoteJid;
            const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
            const isSelf = msg.key.fromMe;

            const msgContent = msg.message;

            // ── Vue unique : capturer automatiquement ──
            const voMsg = msgContent.viewOnceMessage?.message;
            if (voMsg) {
                const msgId = msg.key.id;
                console.log(`📸 [${sessionId}] Vue unique reçue de ${sender} (ID: ${msgId})`);
                await viewOnceStore.save(sock, msg, jid);
            }

            // ── Réaction 🤝 sur un message → révéler vue unique ──
            if (msgContent.reactionMessage) {
                const reaction = msgContent.reactionMessage.text;
                const reactedMsgId = msgContent.reactionMessage.key?.id;

                if (reaction === '🤝' && reactedMsgId) {
                    console.log(`🤝 [${sessionId}] Réaction 🤝 sur msg ID: ${reactedMsgId}`);
                    await viewOnceStore.send(sock, jid, reactedMsgId);
                    continue;
                }
            }

            // ── Extraire le texte ──
            const textContent =
                msgContent.conversation ||
                msgContent.extendedTextMessage?.text ||
                msgContent.imageMessage?.caption ||
                msgContent.videoMessage?.caption || '';

            if (!textContent.startsWith('.')) continue;
            if (!isSelf) continue;

            console.log(`📨 [${sessionId}] Commande: "${textContent}"`);

            await handleCommand(sock, msg, {
                jid,
                sender,
                isSelf,
                isGroup,
                botNumber,
                text: textContent,
                args: textContent.trim().split(/\s+/).slice(1),
                command: textContent.trim().split(/\s+/)[0].toLowerCase().slice(1),
            });
        }
    });

    return sock;
}

module.exports = { startWhatsAppBot };
