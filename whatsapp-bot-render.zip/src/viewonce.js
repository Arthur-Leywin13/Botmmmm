const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');

// Sur Render, /tmp est le seul dossier writable persistant entre les requêtes
// mais attention : il est effacé au redémarrage du service
const STORE_PATH = process.env.VIEWONCE_STORE_PATH 
    || path.join('/tmp', 'viewonce_store');

if (!fs.existsSync(STORE_PATH)) {
    fs.mkdirSync(STORE_PATH, { recursive: true });
}

// msgId -> { jid, sender, type, filePath, caption, timestamp }
const store = new Map();

const viewOnceStore = {
    async save(sock, msg, jid) {
        try {
            const msgId = msg.key.id;
            const sender = msg.key.participant || msg.key.remoteJid;
            const voMsg = msg.message?.viewOnceMessage?.message;
            if (!voMsg) return false;

            const mediaType = voMsg.imageMessage ? 'image' : voMsg.videoMessage ? 'video' : null;
            if (!mediaType) return false;

            const buffer = await downloadMediaMessage(
                { message: voMsg, key: msg.key },
                'buffer',
                {},
                {
                    logger: { level: 'silent', child: () => ({ level: 'silent' }) },
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            const ext = mediaType === 'image' ? 'jpg' : 'mp4';
            const filePath = path.join(STORE_PATH, `${msgId}.${ext}`);
            fs.writeFileSync(filePath, buffer);

            store.set(msgId, {
                jid,
                sender,
                type: mediaType,
                filePath,
                caption: voMsg.imageMessage?.caption || voMsg.videoMessage?.caption || '',
                timestamp: Date.now(),
            });

            console.log(`💾 Vue unique sauvegardé: ${msgId} (${mediaType}) de ${sender}`);
            return true;
        } catch (err) {
            console.error('❌ Erreur sauvegarde vue unique:', err.message);
            return false;
        }
    },

    async send(sock, jid, reactedMsgId) {
        const entry = store.get(reactedMsgId);

        if (!entry) {
            await sock.sendMessage(jid, {
                text: `❌ *Aucun contenu vue unique trouvé*\n\n_Réagis 🤝 directement sur un message vue unique pour le déverrouiller._`
            });
            return;
        }

        if (!fs.existsSync(entry.filePath)) {
            store.delete(reactedMsgId);
            await sock.sendMessage(jid, {
                text: `❌ *Fichier expiré ou supprimé.*`
            });
            return;
        }

        try {
            const fileBuffer = fs.readFileSync(entry.filePath);
            const caption = entry.caption
                ? `👁️ *Vue unique déverrouillée*\n📤 De: ${entry.sender.split('@')[0]}\n\n${entry.caption}`
                : `👁️ *Vue unique déverrouillée*\n📤 De: ${entry.sender.split('@')[0]}`;

            if (entry.type === 'image') {
                await sock.sendMessage(jid, {
                    image: fileBuffer,
                    caption: caption,
                    jpegThumbnail: fileBuffer
                });
            } else if (entry.type === 'video') {
                await sock.sendMessage(jid, {
                    video: fileBuffer,
                    caption: caption
                });
            }

            console.log(`📤 Vue unique envoyé: ${reactedMsgId}`);
        } catch (err) {
            console.error('❌ Erreur envoi vue unique:', err.message);
            await sock.sendMessage(jid, {
                text: `❌ Erreur lors de l'envoi: ${err.message}`
            });
        }
    },

    clearAll() {
        const count = store.size;
        store.clear();
        try {
            const files = fs.readdirSync(STORE_PATH);
            files.forEach(f => {
                try { fs.unlinkSync(path.join(STORE_PATH, f)); } catch (e) {}
            });
        } catch (e) {}
        return count;
    },

    getCount() {
        return store.size;
    },

    getAll() {
        return Array.from(store.entries()).map(([id, data]) => ({
            id,
            sender: data.sender.split('@')[0],
            type: data.type,
            timestamp: data.timestamp
        }));
    }
};

module.exports = { viewOnceStore };
