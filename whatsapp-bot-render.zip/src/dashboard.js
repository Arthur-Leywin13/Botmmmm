const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const path = require('path');
const fs = require('fs');

class DashboardServer {
    constructor(port = 3000) {
        this.port = port;
        this.app = express();
        this.server = http.createServer(this.app);
        this.io = new Server(this.server, {
            cors: { origin: '*' }
        });

        this.sessions = new Map();
        this.qrCallbacks = new Map();
        this.activeBots = new Map();

        this.setupExpress();
        this.setupSocketIO();
    }

    setupExpress() {
        this.app.use(express.static(path.join(__dirname, '..', 'public')));
        this.app.use(express.json());

        this.app.get('/', (req, res) => {
            res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
        });

        this.app.get('/api/sessions', (req, res) => {
            const list = Array.from(this.sessions.entries()).map(([id, s]) => ({
                id,
                status: s.status,
                phone: s.phone || null,
                connectedAt: s.connectedAt || null,
            }));
            res.json({ sessions: list });
        });

        // Health check pour Render
        this.app.get('/health', (req, res) => {
            res.json({ status: 'ok', sessions: this.sessions.size });
        });
    }

    setupSocketIO() {
        this.io.on('connection', (socket) => {
            const sessionId = uuidv4();
            console.log(`🌐 Nouveau visiteur dashboard — Session: ${sessionId}`);

            this.sessions.set(sessionId, {
                socket,
                status: 'idle',
                connectedAt: null,
                phone: null,
            });

            socket.emit('session_id', sessionId);
            this.broadcastStats();

            socket.on('request_qr', async () => {
                const session = this.sessions.get(sessionId);
                if (session) {
                    session.status = 'waiting_qr';
                    this.sessions.set(sessionId, session);
                }
                this.broadcastStats();

                if (this.qrCallbacks.has(sessionId)) return;

                await this.startBotForSession(sessionId, socket);
            });

            socket.on('disconnect', () => {
                console.log(`🔌 Déconnexion dashboard — Session: ${sessionId}`);
                this.sessions.delete(sessionId);
                this.qrCallbacks.delete(sessionId);
                this.broadcastStats();
            });
        });
    }

    async startBotForSession(sessionId, socket) {
        const { startWhatsAppBot } = require('./botFactory');

        try {
            await startWhatsAppBot({
                sessionId,
                authDir: path.join(__dirname, '..', 'auth_sessions', sessionId),
                onQR: async (qr) => {
                    const qrImage = await QRCode.toDataURL(qr, {
                        width: 300,
                        margin: 2,
                        color: { dark: '#128C7E', light: '#ffffff' }
                    });
                    socket.emit('qr_code', { qr: qrImage, sessionId });
                    console.log(`📲 QR envoyé au dashboard — Session: ${sessionId}`);
                },
                onConnected: (phone) => {
                    const session = this.sessions.get(sessionId);
                    if (session) {
                        session.status = 'connected';
                        session.phone = phone;
                        session.connectedAt = new Date().toISOString();
                        this.sessions.set(sessionId, session);
                    }
                    socket.emit('connected', { phone, sessionId });
                    this.broadcastStats();
                    console.log(`✅ Bot connecté — Session: ${sessionId} — ${phone}`);
                },
                onDisconnected: () => {
                    const session = this.sessions.get(sessionId);
                    if (session) {
                        session.status = 'disconnected';
                        this.sessions.set(sessionId, session);
                    }
                    socket.emit('disconnected', { sessionId });
                    this.broadcastStats();
                }
            });
        } catch (err) {
            console.error(`❌ Erreur bot session ${sessionId}:`, err.message);
            socket.emit('error', { message: err.message });
        }
    }

    broadcastStats() {
        const stats = {
            total: this.sessions.size,
            connected: Array.from(this.sessions.values()).filter(s => s.status === 'connected').length,
            waiting: Array.from(this.sessions.values()).filter(s => s.status === 'waiting_qr').length,
            sessions: Array.from(this.sessions.entries()).map(([id, s]) => ({
                id: id.substring(0, 8),
                status: s.status,
                phone: s.phone,
                connectedAt: s.connectedAt,
            }))
        };
        this.io.emit('stats', stats);
    }

    start() {
        // Écouter sur 0.0.0.0 obligatoire pour Render
        this.server.listen(this.port, '0.0.0.0', () => {
            console.log(`\n🌐 Dashboard disponible sur le port ${this.port}`);
            console.log(`📱 Scannez le QR code depuis le dashboard pour connecter votre WhatsApp\n`);
        });
    }
}

module.exports = { DashboardServer };
