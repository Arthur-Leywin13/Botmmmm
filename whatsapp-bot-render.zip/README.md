# 🤖 WhatsApp Bot v2 — Multi-session avec Dashboard Web

Un bot WhatsApp avec tableau de bord web pour la connexion QR, support multi-sessions, et capture automatique des vues uniques.

## 📁 Structure du projet

```
whatsapp-bot/
├── index.js              ← Point d'entrée principal
├── commands.js           ← Toutes les commandes (.menu, .ping, etc.)
├── package.json
├── src/
│   ├── botFactory.js     ← Logique du bot WhatsApp (Baileys)
│   ├── dashboard.js      ← Serveur Express + Socket.IO
│   ├── viewonce.js       ← Capture et envoi des vues uniques
│   └── utils.js          ← Helpers (envoi images, texte, etc.)
├── public/
│   └── index.html        ← Dashboard web (QR code + sessions)
├── assets/               ← Images intégrées aux messages
│   ├── banner.jpg        ← Image du .menu
│   ├── ping.jpg          ← Image du .ping
│   ├── info.jpg          ← Image du .info
│   ├── clear.jpg         ← Image du .clear
│   └── viewonce.jpg      ← Image du .vus
├── auth_info/            ← Session par défaut (créée automatiquement)
├── auth_sessions/        ← Sessions multiples (une par QR scanné)
└── viewonce_store/       ← Fichiers des vues uniques capturées
```

## 🚀 Installation

```bash
npm install
npm start
```

## 🌐 Connexion via le Dashboard

1. Lancez `npm start`
2. Ouvrez **http://localhost:3000** dans votre navigateur
3. Cliquez sur **Générer QR**
4. Sur WhatsApp : ⋮ Menu → Appareils liés → Lier un appareil
5. Scannez le QR code
6. ✅ Le bot est connecté !

**Plusieurs personnes peuvent se connecter simultanément** — chaque visiteur du dashboard obtient sa propre session.

## ⌨️ Commandes disponibles

Toutes les commandes commencent par `.` et ne fonctionnent que depuis votre propre compte (fromMe).

| Commande | Description |
|----------|-------------|
| `.menu` | Affiche le menu avec image intégrée |
| `.ping` | Teste la latence + image |
| `.info` | Infos du bot (uptime, RAM, VUs) + image |
| `.say [message]` | Répéter un message |
| `.img [url] [légende?]` | Envoyer une image depuis une URL |
| `.vus` | Lister les vues uniques stockées |
| `.clear` | Effacer toutes les vues uniques |
| `.sticker` | Convertir une image citée en sticker |

## 👁️ Vue Unique (Vue Éphémère)

Le bot capture **automatiquement** toutes les vues uniques reçues.

**Pour révéler le contenu :**
→ Réagis avec l'emoji 🤝 sur le message vue unique

C'est tout ! Le bot renvoie l'image ou vidéo dans la conversation.

## 🖼️ Images intégrées aux messages

Placez vos propres images dans le dossier `assets/` :
- `banner.jpg` → affiché avec `.menu`
- `ping.jpg` → affiché avec `.ping`
- `info.jpg` → affiché avec `.info`
- `clear.jpg` → affiché avec `.clear`
- `viewonce.jpg` → affiché avec `.vus`

Si un fichier est absent, le bot envoie uniquement le texte (pas d'erreur).

## 🔧 Configuration

Variables d'environnement :
```
PORT=3000    # Port du dashboard web (défaut: 3000)
```

## 📦 Dépendances principales

- `@whiskeysockets/baileys` — Client WhatsApp Web
- `express` + `socket.io` — Dashboard web temps réel
- `qrcode` — Génération du QR code en base64
- `uuid` — IDs de session uniques
