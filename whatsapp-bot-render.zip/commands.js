const path = require('path');
const fs = require('fs');
const { sendImageMessage, sendTextMessage, formatUptime } = require('./src/utils');
const { viewOnceStore } = require('./src/viewonce');

const IMAGES = {
    banner:   path.join(__dirname, 'assets', 'banner.jpg'),
    ping:     path.join(__dirname, 'assets', 'ping.jpg'),
    info:     path.join(__dirname, 'assets', 'info.jpg'),
    clear:    path.join(__dirname, 'assets', 'clear.jpg'),
    viewonce: path.join(__dirname, 'assets', 'viewonce.jpg'),
};

function getImage(key) {
    const local = IMAGES[key];
    return (local && fs.existsSync(local)) ? local : null;
}

const commands = {

    menu: async (sock, msg, ctx) => {
        const voCount = viewOnceStore.getCount();
        const menuText = [
            `╔══════════════════════════╗`,
            `║   🤖 *BOT WHATSAPP v2*   ║`,
            `╠══════════════════════════╣`,
            `║ *Commandes disponibles:*  ║`,
            `╠══════════════════════════╣`,
            `║ *.menu*      → Ce menu    ║`,
            `║ *.ping*      → Latence    ║`,
            `║ *.info*      → Infos bot  ║`,
            `║ *.say* [msg] → Répéter   ║`,
            `║ *.img* [url] → Image      ║`,
            `║ *.vus*       → Vues uniq  ║`,
            `║ *.clear*     → Effacer VU ║`,
            `║ *.sticker*   → Sticker    ║`,
            `╠══════════════════════════╣`,
            `║  🤝 *Réagis sur une VU*   ║`,
            `║  *→ Révèle le contenu !*  ║`,
            `╠══════════════════════════╣`,
            `║  📦 ${voCount} VU stockée(s)       ║`,
            `╚══════════════════════════╝`,
        ].join('\n');
        await sendImageMessage(sock, ctx.jid, getImage('banner'), menuText, msg);
    },

    ping: async (sock, msg, ctx) => {
        const start = Date.now();
        await sendTextMessage(sock, ctx.jid, '🏓 Calcul...', msg);
        const latency = Date.now() - start;
        const text = [
            `⚡ *PING*`,
            ``,
            `🏓 *Latence:* ${latency}ms`,
            `🟢 *Statut:* En ligne`,
            `🕐 *Heure:* ${new Date().toLocaleTimeString('fr-FR')}`,
        ].join('\n');
        await sendImageMessage(sock, ctx.jid, getImage('ping'), text, msg);
    },

    info: async (sock, msg, ctx) => {
        const uptime = formatUptime(process.uptime());
        const ram = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1);
        const voCount = viewOnceStore.getCount();
        const text = [
            `🤖 *BOT INFO*`,
            ``,
            `📱 *Numéro:* +${ctx.botNumber.split('@')[0]}`,
            `⏱️ *Uptime:* ${uptime}`,
            `💾 *RAM:* ${ram} MB`,
            `👁️ *VUs stockées:* ${voCount}`,
            `🟢 *Statut:* Actif`,
            `🛠️ *Version:* 2.0.0`,
        ].join('\n');
        await sendImageMessage(sock, ctx.jid, getImage('info'), text, msg);
    },

    say: async (sock, msg, ctx) => {
        if (!ctx.args.length) return await sendTextMessage(sock, ctx.jid, '❌ Usage: *.say* [message]', msg);
        await sendTextMessage(sock, ctx.jid, `🗣️ ${ctx.args.join(' ')}`, msg);
    },

    img: async (sock, msg, ctx) => {
        if (!ctx.args.length) return await sendTextMessage(sock, ctx.jid, '❌ Usage: *.img* [url] [légende?]', msg);
        const url = ctx.args[0];
        const caption = ctx.args.slice(1).join(' ') || '';
        try {
            await sock.sendMessage(ctx.jid, { image: { url }, caption }, { quoted: msg });
        } catch (e) {
            await sendTextMessage(sock, ctx.jid, `❌ Impossible de charger l'image: ${e.message}`, msg);
        }
    },

    vus: async (sock, msg, ctx) => {
        const list = viewOnceStore.getAll();
        if (list.length === 0) {
            return await sendImageMessage(sock, ctx.jid, getImage('viewonce'),
                `👁️ *Vues Uniques*\n\n_Aucune vue unique stockée._\n\nRéagis 🤝 sur une vue unique pour la capturer !`, msg);
        }
        const items = list.map((v, i) =>
            `${i + 1}. ${v.type === 'image' ? '🖼️' : '🎥'} *${v.sender}* — ${new Date(v.timestamp).toLocaleString('fr-FR')}`
        ).join('\n');
        const text = [`👁️ *Vues Uniques Stockées*`, ``, items, ``, `_Total: ${list.length}_`, `_Réagis 🤝 sur un message VU pour le voir_`].join('\n');
        await sendImageMessage(sock, ctx.jid, getImage('viewonce'), text, msg);
    },

    clear: async (sock, msg, ctx) => {
        const count = viewOnceStore.clearAll();
        const text = [`🗑️ *Nettoyage effectué*`, ``, `✅ *${count}* vue(s) unique(s) supprimée(s)`, `💾 Stockage libéré`].join('\n');
        await sendImageMessage(sock, ctx.jid, getImage('clear'), text, msg);
    },

    sticker: async (sock, msg, ctx) => {
        const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quoted?.imageMessage) {
            return await sendTextMessage(sock, ctx.jid, '❌ *Réponds à une image* pour créer un sticker', msg);
        }
        try {
            const { downloadMediaMessage } = require('@whiskeysockets/baileys');
            const media = await downloadMediaMessage({ message: quoted, key: msg.key }, 'buffer', {});
            await sock.sendMessage(ctx.jid, { sticker: media }, { quoted: msg });
        } catch (e) {
            await sendTextMessage(sock, ctx.jid, `❌ Erreur sticker: ${e.message}`, msg);
        }
    },
};

async function handleCommand(sock, msg, ctx) {
    if (!ctx.isSelf) return;
    const handler = commands[ctx.command];
    if (!handler) {
        return await sendTextMessage(sock, ctx.jid, `❓ Commande inconnue: *.${ctx.command}*\nTapez *.menu* pour voir les commandes`, msg);
    }
    try {
        await handler(sock, msg, ctx);
    } catch (err) {
        console.error(`❌ Erreur commande .${ctx.command}:`, err);
        await sendTextMessage(sock, ctx.jid, `❌ Erreur: ${err.message}`, msg);
    }
}

module.exports = { handleCommand };
