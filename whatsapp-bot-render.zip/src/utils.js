const fs = require('fs');
const path = require('path');

/**
 * Envoie un message texte (en réponse à msg si fourni)
 */
async function sendTextMessage(sock, jid, text, quotedMsg = null) {
    const opts = quotedMsg ? { quoted: quotedMsg } : {};
    return await sock.sendMessage(jid, { text }, opts);
}

/**
 * Envoie une image avec légende — l'image est intégrée dans le message
 * Supporte : chemin local ou URL
 */
async function sendImageMessage(sock, jid, imagePath, caption = '', quotedMsg = null) {
    const opts = quotedMsg ? { quoted: quotedMsg } : {};

    try {
        // Image locale
        if (imagePath && fs.existsSync(imagePath)) {
            const buffer = fs.readFileSync(imagePath);
            return await sock.sendMessage(jid, {
                image: buffer,
                caption: caption,
                jpegThumbnail: buffer
            }, opts);
        }

        // URL d'image
        if (imagePath && (imagePath.startsWith('http://') || imagePath.startsWith('https://'))) {
            return await sock.sendMessage(jid, {
                image: { url: imagePath },
                caption: caption
            }, opts);
        }

        // Pas d'image disponible → message texte seul
        return await sendTextMessage(sock, jid, caption, quotedMsg);

    } catch (err) {
        console.error('❌ Erreur sendImageMessage:', err.message);
        // Fallback texte
        return await sendTextMessage(sock, jid, caption, quotedMsg);
    }
}

/**
 * Envoie un sticker depuis un buffer
 */
async function sendStickerMessage(sock, jid, buffer, quotedMsg = null) {
    const opts = quotedMsg ? { quoted: quotedMsg } : {};
    return await sock.sendMessage(jid, { sticker: buffer }, opts);
}

/**
 * Formate la durée en uptime lisible
 */
function formatUptime(seconds) {
    const d = Math.floor(seconds / 86400);
    const h = Math.floor((seconds % 86400) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    const parts = [];
    if (d > 0) parts.push(`${d}j`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    parts.push(`${s}s`);
    return parts.join(' ');
}

module.exports = {
    sendTextMessage,
    sendImageMessage,
    sendStickerMessage,
    formatUptime
};
