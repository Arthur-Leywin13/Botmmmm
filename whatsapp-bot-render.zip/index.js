const { DashboardServer } = require('./src/dashboard');
const { startWhatsAppBot } = require('./src/botFactory');
const path = require('path');
const fs = require('fs');

const PORT = process.env.PORT || 3000;

async function main() {
    console.log('');
    console.log('╔══════════════════════════════════════╗');
    console.log('║  🤖  BOT WHATSAPP v2  |  DASHBOARD   ║');
    console.log('╚══════════════════════════════════════╝');
    console.log('');

    // Démarrer le serveur dashboard (écoute sur 0.0.0.0 pour Render)
    const dashboard = new DashboardServer(PORT);
    dashboard.start();

    // Vérifier s'il existe une session sauvegardée (connexion auto)
    const defaultAuthDir = path.join(__dirname, 'auth_info');
    if (fs.existsSync(defaultAuthDir)) {
        const credsFile = path.join(defaultAuthDir, 'creds.json');
        if (fs.existsSync(credsFile)) {
            console.log('🔄 Session existante détectée — reconnexion automatique...');
            await startWhatsAppBot({
                sessionId: 'default',
                authDir: defaultAuthDir,
                onQR: () => {
                    console.log('📲 Session expirée. Ouvrez le dashboard pour reconnecter.');
                },
                onConnected: (phone) => {
                    console.log(`✅ Reconnecté automatiquement: ${phone}`);
                },
                onDisconnected: () => {
                    console.log('🔌 Déconnecté de la session par défaut');
                }
            });
        }
    }

    console.log('');
    console.log(`📱 Pour connecter WhatsApp:`);
    console.log(`   → Ouvrez le dashboard et scannez le QR code`);
    console.log('');
}

main().catch(console.error);
